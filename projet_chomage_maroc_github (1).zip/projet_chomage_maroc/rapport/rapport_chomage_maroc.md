# Pourquoi le chômage reste-t-il aussi élevé au Maroc ?

## Étude de cas — Base de données et data science

### 1. Introduction

Le chômage au Maroc ne progresse pas de manière continue : en 2025, le taux national est passé de 13,3 % à 13,0 %. Malgré cette légère baisse, le niveau reste élevé et les difficultés sont particulièrement fortes chez les jeunes, les femmes et les personnes diplômées.

L'objectif de cette étude est d'utiliser des données du Haut-Commissariat au Plan (HCP) pour identifier les catégories de population et les territoires où le chômage est le plus concentré, puis d'interpréter les résultats.

### 2. Données et méthode

Les données proviennent de deux publications officielles du HCP :

- **Enquête Nationale sur l'Emploi (ENE), résultats annuels 2025** ;
- **Nouvelle Enquête sur la Main-d'œuvre (EMO 2026), note d'information du T2 2026**.

Le fichier `data/chomage_maroc.csv` rassemble les valeurs utilisées dans le projet. Chaque observation contient le bloc de données, la période, la catégorie, la valeur, l'unité et la source.

Le taux de chômage est défini comme la part des chômeurs dans la population active âgée de 15 ans et plus. L'EMO 2026 introduit toutefois le « chômage strict », plus restrictif que la mesure de l'ENE : les deux séries ne doivent donc pas être comparées directement.

### 3. Résultats principaux

#### 3.1. Jeunes et femmes particulièrement exposés

En 2025, le taux de chômage atteint **37,2 % chez les 15-24 ans**, contre **13,0 % au niveau national**. Les femmes affichent également un taux élevé de **20,5 %**, contre **10,8 % chez les hommes**.

La légère baisse nationale masque donc une dégradation pour certains groupes : entre 2024 et 2025, le taux augmente chez les jeunes de 15-24 ans et chez les femmes.

#### 3.2. Le paradoxe du diplôme

Le chômage atteint **25,0 % au niveau supérieur**, contre **15,0 % au niveau moyen** et **4,7 % chez les personnes sans diplôme**.

Cette situation suggère une inadéquation entre certaines formations et les emplois disponibles. Elle constitue toutefois une interprétation des données et ne permet pas, à elle seule, de démontrer une causalité.

#### 3.3. Des écarts régionaux importants

Les taux les plus élevés parmi les régions représentées dans le dataset sont ceux des **Régions du Sud (22,8 %)** et de **l'Oriental (22,1 %)**. À l'inverse, **Marrakech-Safi** affiche 8,1 %.

**Casablanca-Settat** se situe à 14,6 %, légèrement au-dessus de la moyenne nationale, mais cette région représente une part importante du volume national de chômeurs.

#### 3.4. Création d'emplois concentrée dans les services

En 2025, l'économie marocaine a créé **193 000 emplois**. Les services ont contribué à hauteur de **123 000 postes**, devant le BTP (+64 000) et l'industrie (+46 000). L'agriculture, forêt et pêche a enregistré une perte de **41 000 postes**.

La création d'emplois ne se traduit donc pas automatiquement par une baisse équivalente du chômage : elle doit aussi correspondre aux profils, aux compétences et aux territoires des nouveaux actifs.

### 4. EMO 2026 : évolution du chômage strict

Au T2 2026, le HCP indique un taux de chômage strict de **9,5 %**, contre 10,8 % au T1 2026. Le taux est de 14,8 % chez les femmes, 8,1 % chez les hommes et 27,2 % chez les 15-24 ans.

Ces résultats confirment la persistance des écarts entre groupes. Toutefois, l'EMO 2026 a modifié la définition du chômage et la méthodologie de l'enquête. Il faut donc éviter de conclure que le chômage est simplement passé de 13,0 % en 2025 à 9,5 % en 2026.

### 5. Conclusion

Le principal enseignement est que le chômage marocain est moins caractérisé par une hausse continue que par une **forte concentration dans certaines catégories**.

Trois enjeux ressortent :

1. **L'insertion professionnelle des jeunes**, dont le taux de chômage dépasse largement la moyenne nationale.
2. **L'accès des femmes à l'emploi**, avec un taux de chômage près de deux fois supérieur à celui des hommes en 2025.
3. **L'adéquation entre formation et emplois disponibles**, illustrée par le niveau élevé du chômage chez les diplômés.

Une baisse durable du chômage suppose donc non seulement de créer davantage d'emplois, mais aussi de développer des emplois adaptés aux compétences des nouveaux actifs et de renforcer l'insertion des jeunes et des femmes.

### 6. Sources

- HCP, *Activité, emploi et chômage — Résultats annuels 2025* : https://www.hcp.ma/file/247824/
- HCP, *Situation du marché du travail au Maroc au deuxième trimestre de 2026 — nouvelle EMO2026* : https://www.hcp.ma/attachment/2897232/
- HCP, *Indicateurs Chômage* : https://www.hcp.ma/Indicateurs-Chomage_r441.html
