"""
Analyse du chômage au Maroc
- Importe data/chomage_maroc.csv
- Génère un graphique PNG à partir des données 2025
- Aucun chiffre n'est codé en dur dans le graphique : les valeurs viennent du CSV.

Exécution depuis la racine du projet :
    python script/analyse_chomage.py
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "chomage_maroc.csv"
OUT = ROOT / "figures" / "taux_chomage_2025_categories.png"

df = pd.read_csv(DATA)

# Sélection du bloc annuel 2025
plot_df = (
    df[(df["bloc"] == "annuel_categorie") & (df["periode"] == "2025")]
    .copy()
    .sort_values("valeur", ascending=True)
)

fig, ax = plt.subplots(figsize=(9, 6))
bars = ax.barh(plot_df["categorie"], plot_df["valeur"])

ax.set_title("Taux de chômage au Maroc par catégorie — 2025", fontsize=14, weight="bold")
ax.set_xlabel("Taux de chômage (%)")
ax.set_ylabel("")
ax.axvline(13.0, linestyle="--", linewidth=1, label="Moyenne nationale : 13,0 %")

for bar, value in zip(bars, plot_df["valeur"]):
    ax.text(value + 0.25, bar.get_y() + bar.get_height()/2, f"{value:.1f} %",
            va="center", fontsize=9)

ax.legend()
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
fig.tight_layout()
fig.savefig(OUT, dpi=200, bbox_inches="tight")
plt.close(fig)

print(f"Graphique créé : {OUT}")
