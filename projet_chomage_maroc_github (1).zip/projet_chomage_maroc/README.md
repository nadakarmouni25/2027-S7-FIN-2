# Étude de cas — Chômage au Maroc

**Université Hassan 1er — École Nationale de Commerce et de Gestion de Settat**  
**Année universitaire : 2025-2026**

## Contenu du dépôt

- `data/chomage_maroc.csv` : dataset utilisé par le script.
- `script/analyse_chomage.py` : script Python qui importe le CSV et génère un graphique.
- `figures/` : emplacement du graphique généré.
- `rapport/rapport_chomage_maroc.docx` : rapport/compte-rendu.
- `rapport/rapport_chomage_maroc.md` : version Markdown du rapport.
- `requirements.txt` : dépendances Python.

## Sources officielles

1. HCP — Activité, emploi et chômage : résultats annuels 2025  
   https://www.hcp.ma/file/247824/
2. HCP — Situation du marché du travail au Maroc au T2 2026, nouvelle EMO2026  
   https://www.hcp.ma/attachment/2897232/
3. HCP — Indicateurs du chômage  
   https://www.hcp.ma/Indicateurs-Chomage_r441.html

## Méthode

Le dataset regroupe les valeurs nécessaires au graphique et les principaux chiffres mobilisés dans le rapport : taux annuels 2024-2025, taux selon le diplôme, taux régionaux, créations d'emplois par secteur et indicateurs EMO 2026.

**Important :** l'EMO 2026 utilise une définition du « chômage strict » et n'est pas directement comparable aux taux issus de l'ENE. La comparaison T1/T2 2026 est en revanche cohérente au sein de l'EMO 2026.

Le dataset fourni ici est une version structurée des valeurs utilisées dans ce projet ; il ne prétend pas reproduire à lui seul l'ensemble des bases statistiques HCP.
